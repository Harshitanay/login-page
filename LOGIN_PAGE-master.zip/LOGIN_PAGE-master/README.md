# LOGIN_PAGE

It is a login page created using HTML-CSS-JavaScript

<p>
<img src="https://raw.githubusercontent.com/rubenshibu/LOGIN_PAGE/master/screenshot/SS_login.png" alt="Login Page" >
</p>